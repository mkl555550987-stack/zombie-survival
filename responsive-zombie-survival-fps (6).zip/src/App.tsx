import ErrorBoundary from "./components/ErrorBoundary";
import Game from "./components/Game";

export default function App() {
  return (
    <ErrorBoundary>
      <Game />
    </ErrorBoundary>
  );
}
