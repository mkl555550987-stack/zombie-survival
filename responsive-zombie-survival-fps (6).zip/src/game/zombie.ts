import * as THREE from "three";

/* ============================================================
   Zombie: dark-red rotting flesh, a creepy sculpted face and
   glowing ember eyes. Built from simple primitives so it stays
   cheap on mobile, but proportioned like a real human body.
   ============================================================ */

export const ZOMBIE_HP = 100;
export const ZOMBIE_DAMAGE = 10;
export const ZOMBIE_SPEED = 1.7;

const TAU = Math.PI * 2;

/** What a zombie needs from the game world (avoids a circular import). */
export interface ZombieHost {
  resolveCircle(x: number, z: number, r: number): { x: number; z: number };
  damagePlayer(amount: number): void;
}

/* ---------------------------- Textures ---------------------------- */

/** Mottled dark-red rotting skin: necrotic patches, bruises, dried blood. */
function makeFleshTexture(): THREE.CanvasTexture {
  const S = 256;
  const canvas = document.createElement("canvas");
  canvas.width = S;
  canvas.height = S;
  const g = canvas.getContext("2d");
  if (g) {
    g.fillStyle = "#4e1317";
    g.fillRect(0, 0, S, S);

    // necrotic blotches + raw exposed flesh
    for (let i = 0; i < 700; i++) {
      const t = Math.random();
      g.fillStyle =
        t > 0.74
          ? "rgba(122,38,32,0.34)"
          : t > 0.46
            ? "rgba(36,6,11,0.42)"
            : "rgba(94,24,24,0.3)";
      g.beginPath();
      g.ellipse(
        Math.random() * S,
        Math.random() * S,
        3 + Math.random() * 14,
        3 + Math.random() * 10,
        Math.random() * TAU,
        0,
        TAU
      );
      g.fill();
    }

    // purple-black bruising
    for (let i = 0; i < 26; i++) {
      g.fillStyle = "rgba(46,9,38,0.3)";
      g.beginPath();
      g.ellipse(
        Math.random() * S,
        Math.random() * S,
        10 + Math.random() * 22,
        8 + Math.random() * 16,
        Math.random() * TAU,
        0,
        TAU
      );
      g.fill();
    }

    // dark veins crawling under the skin
    g.lineWidth = 1.2;
    for (let i = 0; i < 40; i++) {
      g.strokeStyle = "rgba(24,4,10,0.5)";
      g.beginPath();
      let x = Math.random() * S;
      let y = Math.random() * S;
      g.moveTo(x, y);
      for (let k = 0; k < 4; k++) {
        x += (Math.random() - 0.5) * 34;
        y += (Math.random() - 0.5) * 34;
        g.lineTo(x, y);
      }
      g.stroke();
    }

    // dried blood runs
    for (let i = 0; i < 18; i++) {
      const x = Math.random() * S;
      const y = Math.random() * S;
      const h = 12 + Math.random() * 40;
      g.fillStyle = "rgba(70,4,7,0.55)";
      g.fillRect(x, y, 1.5 + Math.random() * 3, h);
    }

    // torn skin / pale sinew streaks
    for (let i = 0; i < 14; i++) {
      g.strokeStyle = "rgba(168,116,96,0.22)";
      g.lineWidth = 1 + Math.random() * 2;
      g.beginPath();
      const x = Math.random() * S;
      const y = Math.random() * S;
      g.moveTo(x, y);
      g.lineTo(x + (Math.random() - 0.5) * 40, y + (Math.random() - 0.5) * 40);
      g.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Creepy face painted straight onto the skull's UVs.
 * The sphere's u = 0.25 column faces +Z (the zombie's forward), so the
 * face is drawn centred at a quarter of the canvas width.
 */
function makeFaceTexture(): THREE.CanvasTexture {
  const W = 512;
  const H = 256;
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const g = canvas.getContext("2d");
  if (g) {
    const cx = W * 0.25; // face centre  (+Z)
    const eyeY = 96; // brow / eye line
    const noseY = 126;
    const mouthY = 154;

    // base rotting skin
    g.fillStyle = "#5a171a";
    g.fillRect(0, 0, W, H);
    for (let i = 0; i < 900; i++) {
      const t = Math.random();
      g.fillStyle =
        t > 0.72
          ? "rgba(124,40,34,0.32)"
          : t > 0.44
            ? "rgba(38,7,12,0.4)"
            : "rgba(96,26,26,0.28)";
      g.beginPath();
      g.ellipse(
        Math.random() * W,
        Math.random() * H,
        3 + Math.random() * 13,
        3 + Math.random() * 9,
        Math.random() * TAU,
        0,
        TAU
      );
      g.fill();
    }

    // dark bald scalp and shadowed jaw/neck
    const scalp = g.createLinearGradient(0, 0, 0, H * 0.34);
    scalp.addColorStop(0, "rgba(10,2,4,0.96)");
    scalp.addColorStop(1, "rgba(10,2,4,0)");
    g.fillStyle = scalp;
    g.fillRect(0, 0, W, H * 0.34);
    const under = g.createLinearGradient(0, H, 0, H * 0.72);
    under.addColorStop(0, "rgba(8,1,3,0.95)");
    under.addColorStop(1, "rgba(8,1,3,0)");
    g.fillStyle = under;
    g.fillRect(0, H * 0.72, W, H * 0.28);

    // gaunt pale cheekbones + brow bone catching the light
    for (const sx of [-46, 46]) {
      const grad = g.createRadialGradient(cx + sx, 124, 1, cx + sx, 124, 26);
      grad.addColorStop(0, "rgba(176,122,100,0.3)");
      grad.addColorStop(1, "rgba(176,122,100,0)");
      g.fillStyle = grad;
      g.beginPath();
      g.ellipse(cx + sx, 124, 26, 18, 0, 0, TAU);
      g.fill();
    }

    // hollow sunken eye sockets — the glowing eyes sit inside these
    for (const sx of [-35, 35]) {
      const grad = g.createRadialGradient(cx + sx, eyeY, 2, cx + sx, eyeY, 32);
      grad.addColorStop(0, "#000000");
      grad.addColorStop(0.5, "rgba(8,1,2,0.95)");
      grad.addColorStop(1, "rgba(34,6,8,0)");
      g.fillStyle = grad;
      g.beginPath();
      g.ellipse(cx + sx, eyeY, 32, 25, 0, 0, TAU);
      g.fill();
    }

    // heavy furrowed brow ridge
    g.strokeStyle = "rgba(14,2,4,0.9)";
    g.lineWidth = 11;
    g.lineCap = "round";
    for (const s of [-1, 1]) {
      g.beginPath();
      g.arc(cx + 35 * s, eyeY + 4, 30, Math.PI * 1.12, Math.PI * 1.88);
      g.stroke();
    }
    // angry frown lines between the brows
    g.lineWidth = 3;
    g.strokeStyle = "rgba(20,3,5,0.8)";
    for (const s of [-1, 1]) {
      g.beginPath();
      g.moveTo(cx + 5 * s, eyeY - 16);
      g.lineTo(cx + 11 * s, eyeY + 8);
      g.stroke();
    }

    // rotted-away nose: a raw black cavity
    g.fillStyle = "#150203";
    g.beginPath();
    g.moveTo(cx, noseY - 16);
    g.lineTo(cx - 13, noseY + 12);
    g.lineTo(cx, noseY + 7);
    g.lineTo(cx + 13, noseY + 12);
    g.closePath();
    g.fill();

    // snarling mouth: a jagged black gash
    g.fillStyle = "#120203";
    g.beginPath();
    g.moveTo(cx - 44, mouthY);
    for (let i = 0; i <= 10; i++) {
      g.lineTo(cx - 44 + i * 8.8, mouthY - 7 + (i % 2 ? 4 : -2));
    }
    g.lineTo(cx + 44, mouthY + 4);
    for (let i = 10; i >= 0; i--) {
      g.lineTo(cx - 44 + i * 8.8, mouthY + 13 + (i % 2 ? -3 : 3));
    }
    g.closePath();
    g.fill();

    // bared, broken teeth (a few missing)
    for (let i = 0; i < 9; i++) {
      if (Math.random() < 0.18) continue;
      const tx = cx - 38 + i * 9.2;
      const th = 5 + Math.random() * 5;
      g.fillStyle = "rgba(206,192,163,0.92)";
      g.beginPath();
      g.moveTo(tx, mouthY - 4);
      g.lineTo(tx + 6.4, mouthY - 4);
      g.lineTo(tx + 4.6, mouthY - 4 + th);
      g.lineTo(tx + 1.8, mouthY - 4 + th);
      g.closePath();
      g.fill();
    }

    // blood running from the mouth down the chin
    for (const sx of [-30, -8, 16, 34]) {
      g.fillStyle = "rgba(78,3,7,0.72)";
      g.fillRect(cx + sx, mouthY + 8, 3 + Math.random() * 4, 14 + Math.random() * 30);
    }
    g.fillStyle = "rgba(96,5,9,0.5)";
    g.beginPath();
    g.ellipse(cx, mouthY + 16, 40, 12, 0, 0, TAU);
    g.fill();

    // torn cheek with crude stitches
    g.strokeStyle = "rgba(24,4,6,0.85)";
    g.lineWidth = 4;
    g.beginPath();
    g.moveTo(cx + 54, 112);
    g.lineTo(cx + 70, 150);
    g.stroke();
    g.lineWidth = 2;
    g.strokeStyle = "rgba(188,170,140,0.45)";
    for (let i = 0; i < 5; i++) {
      const t = i / 4;
      const sx = cx + 54 + 16 * t;
      const sy = 112 + 38 * t;
      g.beginPath();
      g.moveTo(sx - 6, sy - 3);
      g.lineTo(sx + 6, sy + 3);
      g.stroke();
    }

    // scattered cracks across the skull
    g.strokeStyle = "rgba(18,3,5,0.6)";
    g.lineWidth = 1.5;
    for (let i = 0; i < 26; i++) {
      g.beginPath();
      let x = Math.random() * W;
      let y = Math.random() * H;
      g.moveTo(x, y);
      for (let k = 0; k < 3; k++) {
        x += (Math.random() - 0.5) * 30;
        y += (Math.random() - 0.5) * 24;
        g.lineTo(x, y);
      }
      g.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** Soft radial bloom used to make the eyes look like they are burning. */
function makeEyeGlowTexture(): THREE.CanvasTexture {
  const S = 64;
  const canvas = document.createElement("canvas");
  canvas.width = S;
  canvas.height = S;
  const g = canvas.getContext("2d");
  if (g) {
    const grad = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
    grad.addColorStop(0, "rgba(255,236,200,0.95)");
    grad.addColorStop(0.22, "rgba(255,120,40,0.75)");
    grad.addColorStop(0.55, "rgba(190,24,10,0.28)");
    grad.addColorStop(1, "rgba(120,0,0,0)");
    g.fillStyle = grad;
    g.fillRect(0, 0, S, S);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/* ---------------------------- Shared assets ---------------------------- */

interface Part {
  geo: THREE.BufferGeometry;
  pos?: [number, number, number];
  rot?: [number, number, number];
  scale?: [number, number, number];
}

/**
 * Bake several primitives into one geometry. Rigid parts (ribcage, forearm +
 * hand, shin + foot …) become a single mesh, which keeps the draw-call count
 * low enough for phones even with a full wave of zombies on screen.
 */
const BAKE_ATTRS: ReadonlyArray<[name: string, itemSize: number]> = [
  ["position", 3],
  ["normal", 3],
  ["uv", 2],
];

function bake(parts: Part[]): THREE.BufferGeometry {
  // transform each piece into place, expanded to non-indexed so that pieces
  // with different index layouts can always be concatenated safely
  const pieces = parts.map((p) => {
    const src = p.geo.index ? p.geo.toNonIndexed() : p.geo.clone();
    src.applyMatrix4(
      new THREE.Matrix4().compose(
        new THREE.Vector3(...(p.pos ?? [0, 0, 0])),
        new THREE.Quaternion().setFromEuler(
          new THREE.Euler(...(p.rot ?? [0, 0, 0]))
        ),
        new THREE.Vector3(...(p.scale ?? [1, 1, 1]))
      )
    );
    return src;
  });

  const counts = pieces.map((g) => g.getAttribute("position")?.count ?? 0);
  const total = counts.reduce((n, c) => n + c, 0);

  const merged = new THREE.BufferGeometry();
  for (const [name, itemSize] of BAKE_ATTRS) {
    const data = new Float32Array(total * itemSize);
    let offset = 0;
    pieces.forEach((g, i) => {
      const attr = g.getAttribute(name);
      const len = counts[i] * itemSize;
      if (attr) {
        const src = attr.array;
        for (let k = 0; k < len; k++) data[offset + k] = Number(src[k]) || 0;
      }
      offset += len;
    });
    merged.setAttribute(name, new THREE.BufferAttribute(data, itemSize));
  }

  pieces.forEach((g) => g.dispose());
  merged.computeBoundingSphere();
  return merged;
}

/** Geometry + texture set shared by every zombie, owned by the engine. */
export class ZombieAssets {
  readonly fleshTex = makeFleshTexture();
  readonly faceTex = makeFaceTexture();
  readonly eyeGlowTex = makeEyeGlowTexture();
  readonly geo: Record<string, THREE.BufferGeometry>;

  constructor() {
    // raw primitives (disposed again once they have been baked together)
    const chest = new THREE.CapsuleGeometry(0.2, 0.3, 4, 10);
    const pelvis = new THREE.CapsuleGeometry(0.165, 0.1, 4, 8);
    const neck = new THREE.CylinderGeometry(0.055, 0.075, 0.13, 7);
    const shoulder = new THREE.SphereGeometry(0.082, 8, 7);
    const upperArm = new THREE.CapsuleGeometry(0.058, 0.22, 4, 8);
    const foreArm = new THREE.CapsuleGeometry(0.048, 0.24, 4, 8);
    const hand = new THREE.BoxGeometry(0.08, 0.045, 0.09);
    const claw = new THREE.ConeGeometry(0.015, 0.075, 4);
    const shin = new THREE.CapsuleGeometry(0.063, 0.26, 4, 8);
    const foot = new THREE.BoxGeometry(0.095, 0.055, 0.19);
    const rib = new THREE.BoxGeometry(0.11, 0.016, 0.022);
    const eye = new THREE.SphereGeometry(0.038, 10, 8);

    this.geo = {
      // starved, flat-chested torso in one piece
      torso: bake([
        { geo: pelvis, pos: [0, 0.04, 0] },
        { geo: chest, pos: [0, 0.3, 0], scale: [1, 1, 0.82] },
        { geo: neck, pos: [0, 0.52, 0.03], rot: [-0.25, 0, 0] },
      ]),
      // ribs poking through the torn-open chest
      ribs: bake([
        { geo: rib, pos: [0.015, 0.36, 0.145], rot: [0, 0, 0.09] },
        { geo: rib, pos: [0.02, 0.305, 0.15] },
        { geo: rib, pos: [0.015, 0.25, 0.145], rot: [0, 0, -0.09] },
      ]),
      shoulderArm: bake([
        { geo: shoulder },
        { geo: upperArm, pos: [0, -0.17, 0] },
      ]),
      foreHand: bake([
        { geo: foreArm, pos: [0, -0.17, 0] },
        { geo: hand, pos: [0, -0.34, 0] },
      ]),
      claws: bake([
        { geo: claw, pos: [-0.028, -0.395, 0.015], rot: [Math.PI + 0.25, 0, 0] },
        { geo: claw, pos: [0, -0.4, 0.018], rot: [Math.PI + 0.25, 0, 0] },
        { geo: claw, pos: [0.028, -0.395, 0.015], rot: [Math.PI + 0.25, 0, 0] },
      ]),
      lowerLeg: bake([
        { geo: shin, pos: [0, -0.2, 0] },
        { geo: foot, pos: [0, -0.4, 0.05] },
      ]),
      eyes: bake([
        { geo: eye, pos: [0.072, 0.073, 0.148] },
        { geo: eye, pos: [-0.072, 0.073, 0.148] },
      ]),
      thigh: new THREE.CapsuleGeometry(0.082, 0.24, 4, 8),
      skull: new THREE.SphereGeometry(0.19, 20, 16),
      jaw: new THREE.BoxGeometry(0.16, 0.07, 0.15),
      teeth: new THREE.BoxGeometry(0.12, 0.018, 0.095),
      maw: new THREE.BoxGeometry(0.145, 0.07, 0.05),
    };

    for (const g of [
      chest,
      pelvis,
      neck,
      shoulder,
      upperArm,
      foreArm,
      hand,
      claw,
      shin,
      foot,
      rib,
      eye,
    ]) {
      g.dispose();
    }
  }

  dispose(): void {
    this.fleshTex.dispose();
    this.faceTex.dispose();
    this.eyeGlowTex.dispose();
    for (const geometry of Object.values(this.geo)) geometry.dispose();
  }
}

/* ---------------------------- Zombie ---------------------------- */

export class Zombie {
  readonly group = new THREE.Group();
  readonly hitMeshes: THREE.Mesh[] = [];
  hp = ZOMBIE_HP;
  alive = true;
  dying = false;
  deadTime = 0;
  attackCooldown = 0.4 + Math.random() * 0.4;
  hitFlash = 0;
  walkTime = Math.random() * 10;
  readonly phase = Math.random() * TAU;
  readonly speed = ZOMBIE_SPEED * (0.85 + Math.random() * 0.3);

  private readonly fallDir = Math.random() < 0.5 ? 1 : -1;
  private readonly limp = 0.6 + Math.random() * 0.8;
  private readonly twitchRate = 0.5 + Math.random() * 0.9;

  // materials (order matches baseEmissive)
  private readonly mats: THREE.MeshLambertMaterial[] = [];
  private readonly baseEmissive = [0x2a0507, 0x300709, 0x17120e];
  private readonly matEye: THREE.MeshBasicMaterial;
  private readonly matMaw: THREE.MeshBasicMaterial;
  private readonly matGlow: THREE.SpriteMaterial;

  // animated parts
  private readonly upperBody = new THREE.Group();
  private readonly headPivot = new THREE.Group();
  private readonly jawPivot = new THREE.Group();
  private readonly armL = new THREE.Group();
  private readonly armR = new THREE.Group();
  private readonly legL = new THREE.Group();
  private readonly legR = new THREE.Group();
  private jawOpen = 0.08;

  constructor(scene: THREE.Scene, x: number, z: number, a: ZombieAssets) {
    this.group.position.set(x, 0, z);
    // every corpse rotted a little differently
    const size = 0.93 + Math.random() * 0.13;
    this.group.scale.setScalar(size);

    /* ---- materials: dark red, rotten, faintly self-lit ---- */
    const tint = new THREE.Color().setHSL(
      0.99 + Math.random() * 0.02,
      0.16,
      0.78 + Math.random() * 0.16
    );
    const matFlesh = new THREE.MeshLambertMaterial({
      map: a.fleshTex,
      color: tint,
      emissive: this.baseEmissive[0],
      emissiveIntensity: 1,
    });
    const matHead = new THREE.MeshLambertMaterial({
      map: a.faceTex,
      color: tint,
      emissive: this.baseEmissive[1],
      emissiveIntensity: 1,
    });
    const matBone = new THREE.MeshLambertMaterial({
      color: 0xb8a68c,
      emissive: this.baseEmissive[2],
      emissiveIntensity: 1,
    });
    this.mats = [matFlesh, matHead, matBone];

    this.matEye = new THREE.MeshBasicMaterial({
      color: 0xff4a12,
      toneMapped: false,
      transparent: true,
    });
    this.matMaw = new THREE.MeshBasicMaterial({
      color: 0x0d0102,
      transparent: true,
    });
    this.matGlow = new THREE.SpriteMaterial({
      map: a.eyeGlowTex,
      color: 0xff3c10,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    });

    /* ---- legs (children of the root so the hunch doesn't move them) ---- */
    const buildLeg = (side: number, leg: THREE.Group) => {
      leg.position.set(0.1 * side, 0.86, 0);
      const thigh = new THREE.Mesh(a.geo.thigh, matFlesh);
      thigh.position.y = -0.2;
      const shin = new THREE.Group();
      shin.position.y = -0.4;
      shin.rotation.x = 0.28;
      shin.add(new THREE.Mesh(a.geo.lowerLeg, matFlesh)); // shin + foot baked
      leg.add(thigh, shin);
      this.group.add(leg);
    };
    buildLeg(1, this.legL);
    buildLeg(-1, this.legR);

    /* ---- upper body, hunched forward at the waist ---- */
    this.upperBody.position.set(0, 0.86, 0);
    this.upperBody.rotation.x = 0.3;
    this.group.add(this.upperBody);

    // pelvis + ribcage + neck baked into one torso, with bare ribs on top
    const torso = new THREE.Mesh(a.geo.torso, matFlesh);
    const ribs = new THREE.Mesh(a.geo.ribs, matBone);
    this.upperBody.add(torso, ribs);

    /* ---- head: skull + face + glowing eyes + hanging jaw ---- */
    this.headPivot.position.set(0, 0.62, 0.07);
    this.headPivot.rotation.x = -0.34; // cranes up to stare at the player
    this.upperBody.add(this.headPivot);

    const skull = new THREE.Mesh(a.geo.skull, matHead);
    skull.scale.set(0.95, 1.03, 1.0);
    this.headPivot.add(skull);

    // both burning eyes in a single mesh, sunk into the painted sockets
    this.headPivot.add(new THREE.Mesh(a.geo.eyes, this.matEye));

    for (const sx of [0.072, -0.072]) {
      const glow = new THREE.Sprite(this.matGlow);
      glow.position.set(sx, 0.073, 0.176);
      glow.scale.setScalar(0.14);
      this.headPivot.add(glow);
    }

    const maw = new THREE.Mesh(a.geo.maw, this.matMaw);
    maw.position.set(0, -0.062, 0.145);
    this.headPivot.add(maw);

    this.jawPivot.position.set(0, -0.025, 0.02);
    this.headPivot.add(this.jawPivot);
    const jaw = new THREE.Mesh(a.geo.jaw, matFlesh);
    jaw.position.set(0, -0.072, 0.085);
    const teeth = new THREE.Mesh(a.geo.teeth, matBone);
    teeth.position.set(0, -0.032, 0.095);
    this.jawPivot.add(jaw, teeth);

    /* ---- arms, permanently reaching for the player ---- */
    const buildArm = (side: number, arm: THREE.Group): THREE.Mesh => {
      arm.position.set(0.2 * side, 0.4, 0.0);
      arm.rotation.set(-1.15, 0, 0.26 * side);
      const upper = new THREE.Mesh(a.geo.shoulderArm, matFlesh);
      const fore = new THREE.Group();
      fore.position.y = -0.33;
      fore.rotation.x = -0.4; // crooked elbow
      fore.add(
        new THREE.Mesh(a.geo.foreHand, matFlesh), // forearm + hand
        new THREE.Mesh(a.geo.claws, matBone) // three hooked claws
      );
      arm.add(upper, fore);
      this.upperBody.add(arm);
      return upper;
    };
    const upperL = buildArm(1, this.armL);
    const upperR = buildArm(-1, this.armR);

    this.hitMeshes.push(torso, skull, upperL, upperR);
    for (const mesh of this.hitMeshes) mesh.userData.zombie = this;
    scene.add(this.group);
  }

  get removable(): boolean {
    return this.dying && this.deadTime > 1.3;
  }

  /** Returns true if this damage killed the zombie. */
  damage(amount: number): boolean {
    if (!this.alive || this.dying) return false;
    this.hp -= amount;
    this.hitFlash = 0.12;
    if (this.hp <= 0) {
      this.die();
      return true;
    }
    return false;
  }

  private die(): void {
    this.alive = false;
    this.dying = true;
    this.deadTime = 0;
    for (const m of this.mats) m.transparent = true;
    this.jawOpen = 0.55; // dies mid-scream
  }

  update(dt: number, player: THREE.Vector3, host: ZombieHost): void {
    if (this.dying) {
      // corpse crumples, the light leaves its eyes
      this.deadTime += dt;
      const t = Math.min(this.deadTime / 0.6, 1);
      const e = t * t * (3 - 2 * t);
      this.group.rotation.x = -e * (Math.PI / 2) * this.fallDir;
      this.jawPivot.rotation.x = this.jawOpen;
      const fade = THREE.MathUtils.clamp((this.deadTime - 0.35) / 0.7, 0, 1);
      for (const m of this.mats) m.opacity = 1 - fade;
      this.matEye.opacity = Math.max(0, 1 - fade * 1.6);
      this.matMaw.opacity = 1 - fade;
      this.matGlow.opacity = Math.max(0, 0.9 - fade * 1.8);
      return;
    }

    // simple AI: slowly home in on the player on the XZ plane
    const dx = player.x - this.group.position.x;
    const dz = player.z - this.group.position.z;
    const dist = Math.hypot(dx, dz) || 0.0001;

    const targetYaw = Math.atan2(dx, dz);
    let dyaw = targetYaw - this.group.rotation.y;
    while (dyaw > Math.PI) dyaw -= Math.PI * 2;
    while (dyaw < -Math.PI) dyaw += Math.PI * 2;
    this.group.rotation.y += dyaw * Math.min(1, dt * 8);

    let targetJaw = 0.08;

    if (dist > 1.1) {
      const res = host.resolveCircle(
        this.group.position.x + (dx / dist) * this.speed * dt,
        this.group.position.z + (dz / dist) * this.speed * dt,
        0.35
      );
      this.group.position.x = res.x;
      this.group.position.z = res.z;

      // dragging, uneven shamble
      this.walkTime += dt * 8;
      const swing = Math.sin(this.walkTime) * 0.5;
      this.legL.rotation.x = 0.16 + swing;
      this.legR.rotation.x = 0.16 - swing * this.limp;
      this.armL.rotation.x = -1.15 - swing * 0.35;
      this.armR.rotation.x = -1.15 + swing * 0.35;
      this.upperBody.rotation.z = Math.sin(this.walkTime * 0.5) * 0.07;
      this.upperBody.position.y = 0.86 + Math.abs(Math.sin(this.walkTime)) * 0.02;
      if (dist < 4) targetJaw = 0.3; // starts snarling as it closes in
    } else {
      // in range: bite the player (with cooldown)
      this.attackCooldown -= dt;
      if (this.attackCooldown <= 0) {
        this.attackCooldown = 0.85;
        host.damagePlayer(ZOMBIE_DAMAGE);
      }
      this.walkTime += dt * 4;
      const sway = Math.sin(this.walkTime + this.phase) * 0.14;
      this.armL.rotation.x = -1.3 - sway;
      this.armR.rotation.x = -1.3 + sway;
      targetJaw = 0.62; // mouth gaping wide to bite
    }

    // jaw + head twitches
    this.jawOpen += (targetJaw - this.jawOpen) * Math.min(1, dt * 11);
    this.jawPivot.rotation.x = this.jawOpen;
    const twitch = Math.sin(this.walkTime * this.twitchRate + this.phase);
    this.headPivot.rotation.y = twitch * 0.13;
    this.headPivot.rotation.z = Math.sin(this.walkTime * 0.4 + this.phase) * 0.09;

    // white hit-flash feedback
    if (this.hitFlash > 0) {
      this.hitFlash -= dt;
      const intensity = Math.min(1, this.hitFlash * 7) * 0.85;
      for (const m of this.mats) {
        m.emissive.setHex(0xffffff);
        m.emissiveIntensity = intensity;
      }
    } else {
      // restore the rotten dark-red self-glow
      this.mats.forEach((m, i) => {
        m.emissive.setHex(this.baseEmissive[i]);
        m.emissiveIntensity = 1;
      });
    }

    // eyes burn like embers — brighter the closer it gets
    const pulse = 0.78 + Math.sin(this.walkTime * 2.2 + this.phase) * 0.18;
    const near = THREE.MathUtils.clamp((18 - dist) / 18, 0, 1);
    this.matGlow.opacity = pulse * (0.55 + near * 0.55);
    this.matEye.color.setRGB(1, 0.26 + near * 0.12, 0.05);
  }

  disposeMaterials(): void {
    for (const m of this.mats) m.dispose();
    this.matEye.dispose();
    this.matMaw.dispose();
    this.matGlow.dispose();
  }
}
