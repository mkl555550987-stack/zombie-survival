import * as THREE from "three";
import { Zombie, ZombieAssets } from "./zombie";

/* ============================ Types & Store ============================ */

export type GameState = "idle" | "playing" | "won" | "lost";

export interface GameStats {
  health: number;
  wave: number;
  totalWaves: number;
  ammo: number;
  reserve: number;
  zombiesAlive: number;
  zombiesRemaining: number;
  kills: number;
  state: GameState;
  message: string;
  hitTick: number;
  hurtTick: number;
  locked: boolean;
}

const INITIAL_STATS: GameStats = {
  health: 100,
  wave: 0,
  totalWaves: 3,
  ammo: 30,
  reserve: 150,
  zombiesAlive: 0,
  zombiesRemaining: 0,
  kills: 0,
  state: "idle",
  message: "",
  hitTick: 0,
  hurtTick: 0,
  locked: false,
};

/** Tiny external store so React can subscribe to game state changes. */
export class GameStore {
  private listeners = new Set<() => void>();
  private snapshot: GameStats = { ...INITIAL_STATS };

  subscribe = (fn: () => void): (() => void) => {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  };

  getSnapshot = (): GameStats => this.snapshot;

  update = (partial: Partial<GameStats>): void => {
    this.snapshot = { ...this.snapshot, ...partial };
    this.listeners.forEach((fn) => fn());
  };
}

/* ============================ Constants ============================ */

const MAP_LIMIT = 70;
const GROUND_SIZE = 144;
const PITCH = 24;
const CELL = 4.5;
const PLAYER_RADIUS = 0.45;
const PLAYER_HEIGHT = 1.7;
const PLAYER_SPEED = 5.2;
const WAVES: readonly number[] = [5, 9, 14];
const MAG_SIZE = 30;
const START_RESERVE = 150;

const SHOT_DAMAGE = 34;
const LAMP_HEIGHT = 4.1;
const LAMP_INTENSITY = 230;
const FIRE_INTERVAL = 0.13;
const RELOAD_TIME = 1.3;
const AIM_POINT = new THREE.Vector2(0, 0);

/* ============================ Helpers ============================ */

/** Deterministic PRNG so the city layout is always the same. */
function mulberry32(seed: number): () => number {
  let s = seed;
  return () => {
    s |= 0;
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Procedural asphalt texture with sidewalks and lane markings. */
function makeRoadTexture(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const g = canvas.getContext("2d");
  if (g) {
    g.fillStyle = "#2b3242";
    g.fillRect(0, 0, size, size);
    for (let i = 0; i < 5000; i++) {
      g.fillStyle =
        Math.random() > 0.5 ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)";
      g.fillRect(Math.random() * size, Math.random() * size, 2, 2);
    }
    // sidewalk strips along tile edges (streets run on tile boundaries)
    g.fillStyle = "#454f64";
    g.fillRect(0, 0, size, 26);
    g.fillRect(0, size - 26, size, 26);
    g.fillRect(0, 0, 26, size);
    g.fillRect(size - 26, 0, 26, size);
    // dashed lane lines down the middle of each street
    g.strokeStyle = "rgba(240,214,110,0.8)";
    g.lineWidth = 4;
    g.setLineDash([26, 22]);
    g.beginPath();
    g.moveTo(0, size / 2);
    g.lineTo(size, size / 2);
    g.stroke();
    g.beginPath();
    g.moveTo(size / 2, 0);
    g.lineTo(size / 2, size);
    g.stroke();
    g.setLineDash([]);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(6, 6); // 6 tiles * 24 units = 144 unit ground
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/** Soft radial glow used as a fake light pool under street lamps. */
function makeGlowTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const g = canvas.getContext("2d");
  if (g) {
    const grad = g.createRadialGradient(
      size / 2,
      size / 2,
      0,
      size / 2,
      size / 2,
      size / 2
    );
    grad.addColorStop(0, "rgba(255,221,170,0.95)");
    grad.addColorStop(0.4, "rgba(255,190,115,0.5)");
    grad.addColorStop(1, "rgba(255,160,70,0)");
    g.fillStyle = grad;
    g.fillRect(0, 0, size, size);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/* ============================ 8-bit style SFX (WebAudio synth) ============================ */

class AudioFX {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;

  ensure(): void {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    try {
      const Ctor =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!Ctor) return;
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.22;
      this.master.connect(this.ctx.destination);
    } catch {
      this.ctx = null;
    }
  }

  private tone(
    freq: number,
    dur: number,
    gain: number,
    type: OscillatorType,
    when = 0
  ): void {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const t0 = ctx.currentTime + when;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    osc.frequency.exponentialRampToValueAtTime(
      Math.max(30, freq * 0.4),
      t0 + dur
    );
    g.gain.setValueAtTime(gain, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    osc.connect(g);
    g.connect(this.master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }

  private noise(dur: number, cutoff: number, gain: number, when = 0): void {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const t0 = ctx.currentTime + when;
    const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
    const buffer = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = cutoff;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.master);
    src.start(t0);
    src.stop(t0 + dur + 0.02);
  }

  shoot(): void {
    this.ensure();
    this.noise(0.11, 1500, 0.9);
    this.tone(95, 0.1, 0.5, "sawtooth");
  }
  click(): void {
    this.ensure();
    this.tone(180, 0.05, 0.2, "square");
  }
  reload(): void {
    this.ensure();
    this.noise(0.09, 700, 0.35);
    this.noise(0.12, 900, 0.3, 0.16);
  }
  hurt(): void {
    this.ensure();
    this.tone(120, 0.22, 0.5, "sawtooth");
    this.noise(0.18, 500, 0.35);
  }
  hit(): void {
    this.ensure();
    this.noise(0.07, 2200, 0.4);
    this.tone(170, 0.07, 0.25, "square");
  }
  die(): void {
    this.ensure();
    this.tone(75, 0.3, 0.35, "sawtooth");
  }
  wave(): void {
    this.ensure();
    this.tone(340, 0.35, 0.22, "sine");
    this.tone(255, 0.45, 0.22, "sine", 0.22);
  }

  dispose(): void {
    if (this.ctx) {
      const ctx = this.ctx;
      this.ctx = null;
      void ctx.close().catch(() => undefined);
    }
  }
}

/* ============================ World collision ============================ */

interface AABB {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

/* ============================ Engine ============================ */

export class ZombieEngine {
  readonly store: GameStore;
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;

  // player
  private pos = new THREE.Vector3(0, 0, 12);
  private yaw = 0;
  private pitch = 0;
  private lookDX = 0;
  private lookDY = 0;
  private keys = new Set<string>();
  private joystick = { x: 0, y: 0 };
  private firing = false;
  private locked = false;
  private isTouch = false;
  private moving = false;
  private bobTime = 0;
  private idleTime = 0;

  // game state
  private health = 100;
  private mag = MAG_SIZE;
  private reserve = START_RESERVE;
  private kills = 0;
  private zombies: Zombie[] = [];
  private waveIndex = -1;
  private toSpawn = 0;
  private spawnTimer = 0;
  private waveEnding = false;
  private waveBreakTimer = 0;
  private messageTimer = 0;

  // gun state
  private fireCooldown = 0;
  private reloading = false;
  private reloadTimer = 0;
  private recoil = 0;
  private flashTime = 0;
  private tracerTime = 0;
  private flickerTime = 0;

  // world
  private colliders: AABB[] = [];
  private zAssets!: ZombieAssets;
  private streetLights: THREE.PointLight[] = [];
  private lampSpots: { x: number; z: number }[] = [];
  private lampSyncTimer = 0;
  private buildingMesh!: THREE.InstancedMesh<
    THREE.BoxGeometry,
    THREE.MeshLambertMaterial
  >;
  private groundMesh!: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshLambertMaterial>;
  private shootTargets: THREE.Object3D[] = [];

  // gun / fx objects
  private gun!: THREE.Group;
  private muzzleFlash!: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>;
  private muzzleLight!: THREE.PointLight;
  private tracer!: THREE.Line<THREE.BufferGeometry, THREE.LineBasicMaterial>;
  private raycaster = new THREE.Raycaster();
  private readonly tmpDir = new THREE.Vector3();
  private readonly tmpMuzzle = new THREE.Vector3();

  private audio = new AudioFX();
  private onError?: (err: unknown) => void;
  private raf = 0;
  private lastT = 0;
  private disposed = false;
  private resizeObserver: ResizeObserver;
  private touchLook = new Map<number, { x: number; y: number }>();

  constructor(
    container: HTMLElement,
    store: GameStore,
    onError?: (err: unknown) => void
  ) {
    this.container = container;
    this.store = store;
    this.onError = onError;
    this.isTouch = "ontouchstart" in window || navigator.maxTouchPoints > 0;

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setClearColor(0x121a2e);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.55;
    const canvas = this.renderer.domElement;
    canvas.style.display = "block";
    canvas.style.width = "100%";
    canvas.style.height = "100%";
    canvas.style.objectFit = "contain";
    canvas.style.touchAction = "none";
    container.appendChild(canvas);

    this.scene = new THREE.Scene();
    // lighter haze so the district reads clearly while staying night-time
    this.scene.fog = new THREE.FogExp2(0x121a2e, 0.011);

    this.camera = new THREE.PerspectiveCamera(72, 1, 0.08, 160);
    this.camera.rotation.order = "YXZ";
    this.camera.position.set(0, PLAYER_HEIGHT, 12);
    this.scene.add(this.camera);

    this.zAssets = new ZombieAssets();
    this.buildLights();
    this.buildCity();
    this.buildGun();
    this.buildPlayerLight();

    this.bindEvents();
    this.resize();
    this.resizeObserver = new ResizeObserver(this.resize);
    this.resizeObserver.observe(container);

    this.lastT = performance.now();
    this.raf = requestAnimationFrame(this.tick);
  }

  /* ---------------------------- World building ---------------------------- */

  private buildLights(): void {
    // brighter moonlit night: strong key moon + sky fill + ambient base
    const moon = new THREE.DirectionalLight(0xc8d8ff, 4.4);
    moon.position.set(35, 55, -25);
    this.scene.add(moon);

    // cool bounce from the opposite side so building faces are never pitch black
    const bounce = new THREE.DirectionalLight(0x8fa6d8, 1.6);
    bounce.position.set(-30, 25, 35);
    this.scene.add(bounce);

    this.scene.add(new THREE.HemisphereLight(0x5c6e9c, 0x1a1f2b, 3.0));
    this.scene.add(new THREE.AmbientLight(0x6878a0, 1.1));
  }

  private buildCity(): void {
    const rand = mulberry32(20250117);

    // ground / roads
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(GROUND_SIZE, GROUND_SIZE),
      new THREE.MeshLambertMaterial({ map: makeRoadTexture() })
    );
    ground.rotation.x = -Math.PI / 2;
    this.scene.add(ground);
    this.groundMesh = ground;

    // buildings — North Quarter District grid of city blocks
    interface BuildingSpec {
      x: number;
      z: number;
      hw: number;
      hd: number;
      h: number;
    }
    const palette = [
      0x3c4457, 0x333b4c, 0x454e63, 0x2e3545, 0x4a5469, 0x363e50, 0x2a313f,
      0x414a5e, 0x383f52, 0x303744,
    ];
    const specs: BuildingSpec[] = [];
    for (let bx = -2; bx <= 2; bx++) {
      for (let bz = -2; bz <= 2; bz++) {
        const cx = bx * PITCH;
        const cz = bz * PITCH;
        for (const ox of [-CELL, CELL]) {
          for (const oz of [-CELL, CELL]) {
            if (rand() < 0.14) continue; // vacant lot
            const hw = 3.2 + rand() * 1.3;
            const hd = 3.2 + rand() * 1.3;
            const h = 6 + Math.pow(rand(), 1.7) * 34;
            specs.push({
              x: cx + ox + (rand() - 0.5) * 1.6,
              z: cz + oz + (rand() - 0.5) * 1.6,
              hw,
              hd,
              h,
            });
          }
        }
      }
    }

    const bGeo = new THREE.BoxGeometry(1, 1, 1);
    const bMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    const buildings = new THREE.InstancedMesh(bGeo, bMat, specs.length);
    const m4 = new THREE.Matrix4();
    const quat = new THREE.Quaternion();
    const scl = new THREE.Vector3();
    const pos = new THREE.Vector3();
    const color = new THREE.Color();
    specs.forEach((s, i) => {
      pos.set(s.x, s.h / 2, s.z);
      scl.set(s.hw * 2, s.h, s.hd * 2);
      m4.compose(pos, quat, scl);
      buildings.setMatrixAt(i, m4);
      color.setHex(palette[Math.floor(rand() * palette.length)]);
      color.multiplyScalar(0.75 + rand() * 0.5);
      buildings.setColorAt(i, color);
      this.colliders.push({
        minX: s.x - s.hw,
        maxX: s.x + s.hw,
        minZ: s.z - s.hd,
        maxZ: s.z + s.hd,
      });
    });
    buildings.instanceMatrix.needsUpdate = true;
    if (buildings.instanceColor) buildings.instanceColor.needsUpdate = true;
    this.scene.add(buildings);
    this.buildingMesh = buildings;

    // red rooftop beacons on tall buildings
    const beaconSpecs = specs.filter((s) => s.h > 24 && rand() < 0.4);
    if (beaconSpecs.length > 0) {
      const beacons = new THREE.InstancedMesh(
        new THREE.SphereGeometry(0.14, 6, 6),
        new THREE.MeshBasicMaterial({ color: 0xff3344 }),
        beaconSpecs.length
      );
      beaconSpecs.forEach((s, i) => {
        pos.set(s.x, s.h + 0.4, s.z);
        scl.set(1, 1, 1);
        m4.compose(pos, quat, scl);
        beacons.setMatrixAt(i, m4);
      });
      beacons.instanceMatrix.needsUpdate = true;
      this.scene.add(beacons);
    }

    // street lamps: every intersection + mid-block lamps down every street
    const streetCoords = [-48, -24, 0, 24, 48];
    const midCoords = [-36, -12, 12, 36];
    const lampPos: { x: number; z: number }[] = [];
    for (const sx of streetCoords) {
      for (const sz of streetCoords) lampPos.push({ x: sx, z: sz }); // crossings
      for (const mz of midCoords) lampPos.push({ x: sx, z: mz }); // N/S streets
    }
    for (const sz of streetCoords) {
      for (const mx of midCoords) lampPos.push({ x: mx, z: sz }); // E/W streets
    }
    this.lampSpots = lampPos;

    const poleMesh = new THREE.InstancedMesh(
      new THREE.CylinderGeometry(0.05, 0.07, 4.4, 6),
      new THREE.MeshLambertMaterial({ color: 0x2a3040 }),
      lampPos.length
    );
    const headMesh = new THREE.InstancedMesh(
      new THREE.BoxGeometry(0.42, 0.14, 0.24),
      new THREE.MeshStandardMaterial({
        color: 0x3a3426,
        emissive: 0xffd8a0,
        emissiveIntensity: 5.5,
      }),
      lampPos.length
    );
    const glowMesh = new THREE.InstancedMesh(
      new THREE.PlaneGeometry(10, 10),
      new THREE.MeshBasicMaterial({
        map: makeGlowTexture(),
        transparent: true,
        opacity: 0.62,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
      lampPos.length
    );
    const glowQuat = new THREE.Quaternion().setFromEuler(
      new THREE.Euler(-Math.PI / 2, 0, 0)
    );

    lampPos.forEach((p, i) => {
      pos.set(p.x, 2.2, p.z);
      scl.set(1, 1, 1);
      m4.compose(pos, quat, scl);
      poleMesh.setMatrixAt(i, m4);

      pos.set(p.x, 4.35, p.z);
      m4.compose(pos, quat, scl);
      headMesh.setMatrixAt(i, m4);

      pos.set(p.x, 0.02, p.z);
      m4.compose(pos, glowQuat, scl);
      glowMesh.setMatrixAt(i, m4);
    });

    // a pool of real point lights that re-targets the lamps nearest the player,
    // so every street the player walks down is genuinely lit (without 65 lights)
    const poolSize = this.isTouch ? 7 : 10;
    for (let i = 0; i < poolSize; i++) {
      const light = new THREE.PointLight(0xffc98a, 0, 34, 2);
      light.position.set(0, LAMP_HEIGHT, 0);
      this.scene.add(light);
      this.streetLights.push(light);
    }
    this.assignStreetLights();
    poleMesh.instanceMatrix.needsUpdate = true;
    headMesh.instanceMatrix.needsUpdate = true;
    glowMesh.instanceMatrix.needsUpdate = true;
    this.scene.add(poleMesh, headMesh, glowMesh);

    this.shootTargets = [buildings, ground];
  }

  private buildGun(): void {
    const g = new THREE.Group();
    const metal = new THREE.MeshStandardMaterial({
      color: 0x22262e,
      roughness: 0.35,
      metalness: 0.85,
    });
    const dark = new THREE.MeshStandardMaterial({
      color: 0x111318,
      roughness: 0.6,
      metalness: 0.4,
    });
    const accent = new THREE.MeshStandardMaterial({
      color: 0x0e7d8a,
      emissive: 0x0e7d8a,
      emissiveIntensity: 0.35,
      roughness: 0.4,
    });

    const body = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.09, 0.42), metal);
    const barrel = new THREE.Mesh(
      new THREE.BoxGeometry(0.06, 0.06, 0.4),
      dark
    );
    barrel.position.set(0, 0.055, -0.22);
    const muzzle = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.08, 0.05),
      dark
    );
    muzzle.position.set(0, 0.055, -0.44);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.18, 0.12), dark);
    grip.position.set(-0.02, -0.12, 0.08);
    grip.rotation.x = -0.35;
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.16, 0.1), metal);
    mag.position.set(0.02, -0.16, 0.02);
    mag.rotation.x = 0.15;
    const sight = new THREE.Mesh(
      new THREE.BoxGeometry(0.03, 0.03, 0.1),
      accent
    );
    sight.position.set(0, 0.07, -0.05);
    const rail = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.02, 0.3), dark);
    rail.position.set(0, 0.055, -0.05);

    g.add(body, barrel, muzzle, grip, mag, sight, rail);
    g.position.set(0.32, -0.28, -0.55);
    g.rotation.set(-0.08, -0.15, 0.05);
    this.camera.add(g);
    this.gun = g;

    this.muzzleFlash = new THREE.Mesh(
      new THREE.PlaneGeometry(0.16, 0.16),
      new THREE.MeshBasicMaterial({
        color: 0xffd27a,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    this.muzzleFlash.position.set(0, 0.055, -0.5);
    g.add(this.muzzleFlash);

    this.muzzleLight = new THREE.PointLight(0xffc36b, 0, 6, 2);
    this.muzzleLight.position.set(0, 0.055, -0.5);
    g.add(this.muzzleLight);

    this.tracer = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(),
        new THREE.Vector3(),
      ]),
      new THREE.LineBasicMaterial({
        color: 0xffdd88,
        transparent: true,
        opacity: 0,
      })
    );
    this.tracer.visible = false;
    this.scene.add(this.tracer);
  }

  private buildPlayerLight(): void {
    // flashlight so the player can see in the dark
    const flashlight = new THREE.SpotLight(0xfff4e2, 900, 70, 0.58, 0.6, 2);
    flashlight.position.set(0, 0, 0);
    const target = new THREE.Object3D();
    target.position.set(0, 0, -8);
    this.camera.add(flashlight);
    this.camera.add(target);
    flashlight.target = target;
    // dim fill light so the gun silhouette is visible
    this.camera.add(new THREE.PointLight(0xaabbdd, 1.8, 4, 2));
  }

  /* ---------------------------- Collisions ---------------------------- */

  /** Push a circle (x,z,r) out of every building and keep it on the map. */
  resolveCircle(x: number, z: number, r: number): { x: number; z: number } {
    let nx = x;
    let nz = z;
    for (const b of this.colliders) {
      const cx = THREE.MathUtils.clamp(nx, b.minX, b.maxX);
      const cz = THREE.MathUtils.clamp(nz, b.minZ, b.maxZ);
      const dx = nx - cx;
      const dz = nz - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 > 1e-8) {
          const d = Math.sqrt(d2);
          nx = cx + (dx / d) * r;
          nz = cz + (dz / d) * r;
        } else {
          const pushL = nx - b.minX;
          const pushR = b.maxX - nx;
          const pushT = nz - b.minZ;
          const pushB = b.maxZ - nz;
          const m = Math.min(pushL, pushR, pushT, pushB);
          if (m === pushL) nx = b.minX - r;
          else if (m === pushR) nx = b.maxX + r;
          else if (m === pushT) nz = b.minZ - r;
          else nz = b.maxZ + r;
        }
      }
    }
    nx = THREE.MathUtils.clamp(nx, -MAP_LIMIT, MAP_LIMIT);
    nz = THREE.MathUtils.clamp(nz, -MAP_LIMIT, MAP_LIMIT);
    return { x: nx, z: nz };
  }

  /* ---------------------------- Events ---------------------------- */

  private bindEvents(): void {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("pointerup", this.onPointerUp);
    window.addEventListener("mousemove", this.onMouseMove);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("pointerlockchange", this.onLockChange);
    window.addEventListener("resize", this.resize);
    const el = this.renderer.domElement;
    el.addEventListener("pointerdown", this.onCanvasPointerDown);
    el.addEventListener("touchstart", this.onTouchStart, { passive: false });
    el.addEventListener("touchmove", this.onTouchMove, { passive: false });
    el.addEventListener("touchend", this.onTouchEnd);
    el.addEventListener("touchcancel", this.onTouchEnd);
    el.addEventListener("contextmenu", this.onContextMenu);
    this.container.addEventListener("click", this.onContainerClick);
  }

  private onKeyDown = (e: KeyboardEvent): void => {
    this.audio.ensure();
    switch (e.code) {
      case "KeyW":
      case "ArrowUp":
        this.keys.add("w");
        e.preventDefault();
        break;
      case "KeyS":
      case "ArrowDown":
        this.keys.add("s");
        e.preventDefault();
        break;
      case "KeyA":
      case "ArrowLeft":
        this.keys.add("a");
        e.preventDefault();
        break;
      case "KeyD":
      case "ArrowRight":
        this.keys.add("d");
        e.preventDefault();
        break;
      case "KeyR":
        this.reload();
        break;
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    switch (e.code) {
      case "KeyW":
      case "ArrowUp":
        this.keys.delete("w");
        break;
      case "KeyS":
      case "ArrowDown":
        this.keys.delete("s");
        break;
      case "KeyA":
      case "ArrowLeft":
        this.keys.delete("a");
        break;
      case "KeyD":
      case "ArrowRight":
        this.keys.delete("d");
        break;
    }
  };

  private onCanvasPointerDown = (e: PointerEvent): void => {
    e.preventDefault();
    this.audio.ensure();
    if (this.isTouch) return;
    if (this.store.getSnapshot().state === "playing") {
      if (!this.locked) this.lockPointer();
      this.firing = true;
    }
  };

  private onPointerUp = (): void => {
    this.firing = false;
  };

  private onMouseMove = (e: MouseEvent): void => {
    if (document.pointerLockElement === this.renderer.domElement) {
      this.lookDX += e.movementX;
      this.lookDY += e.movementY;
    }
  };

  private onLockChange = (): void => {
    this.locked = document.pointerLockElement === this.renderer.domElement;
    if (!this.locked) this.firing = false;
    this.store.update({ locked: this.locked });
  };

  private onContainerClick = (): void => {
    if (
      !this.isTouch &&
      this.store.getSnapshot().state === "playing" &&
      !this.locked
    ) {
      this.lockPointer();
    }
  };

  private onTouchStart = (e: TouchEvent): void => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      this.touchLook.set(t.identifier, { x: t.clientX, y: t.clientY });
    }
  };

  private onTouchMove = (e: TouchEvent): void => {
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      const prev = this.touchLook.get(t.identifier);
      if (!prev) continue;
      this.lookDX += t.clientX - prev.x;
      this.lookDY += t.clientY - prev.y;
      prev.x = t.clientX;
      prev.y = t.clientY;
    }
  };

  private onTouchEnd = (e: TouchEvent): void => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      this.touchLook.delete(e.changedTouches[i].identifier);
    }
  };

  private onContextMenu = (e: Event): void => {
    e.preventDefault();
  };

  private onBlur = (): void => {
    this.firing = false;
  };

  private resize = (): void => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    if (w === 0 || h === 0) return;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  /* ---------------------------- Public API ---------------------------- */

  start(): void {
    this.reset();
    this.audio.ensure();
    this.store.update({ state: "playing", message: "", hitTick: 0, hurtTick: 0 });
    this.startWave(0);
    if (!this.isTouch) this.lockPointer();
  }

  setFiring(firing: boolean): void {
    this.firing = firing;
  }

  setJoystick(x: number, y: number): void {
    this.joystick.x = THREE.MathUtils.clamp(x, -1, 1);
    this.joystick.y = THREE.MathUtils.clamp(y, -1, 1);
  }

  reload(): void {
    if (this.store.getSnapshot().state !== "playing") return;
    if (this.reloading || this.mag >= MAG_SIZE || this.reserve <= 0) return;
    this.reloading = true;
    this.reloadTimer = RELOAD_TIME;
    this.audio.reload();
  }

  lockPointer(): void {
    if (this.isTouch) return;
    const el = this.renderer.domElement;
    if (document.pointerLockElement !== el && el.requestPointerLock) {
      try {
        el.requestPointerLock();
      } catch {
        /* pointer lock can fail — game still works without it */
      }
    }
  }

  damagePlayer(amount: number): void {
    if (this.store.getSnapshot().state !== "playing") return;
    this.health = Math.max(0, this.health - amount);
    this.audio.hurt();
    const s = this.store.getSnapshot();
    this.store.update({ health: this.health, hurtTick: s.hurtTick + 1 });
    if (this.health <= 0) {
      this.store.update({ state: "lost", message: "" });
      this.firing = false;
    }
  }

  dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("pointerup", this.onPointerUp);
    window.removeEventListener("mousemove", this.onMouseMove);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("pointerlockchange", this.onLockChange);
    window.removeEventListener("resize", this.resize);
    const el = this.renderer.domElement;
    el.removeEventListener("pointerdown", this.onCanvasPointerDown);
    el.removeEventListener("touchstart", this.onTouchStart);
    el.removeEventListener("touchmove", this.onTouchMove);
    el.removeEventListener("touchend", this.onTouchEnd);
    el.removeEventListener("touchcancel", this.onTouchEnd);
    el.removeEventListener("contextmenu", this.onContextMenu);
    this.container.removeEventListener("click", this.onContainerClick);
    // teardown must never throw: React unmounts through this path
    try {
      this.resizeObserver?.disconnect();
      this.audio.dispose();
      for (const z of this.zombies) {
        this.scene.remove(z.group);
        z.disposeMaterials();
      }
      this.zombies = [];
      this.scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        const mat = mesh.material as
          | THREE.Material
          | THREE.Material[]
          | undefined;
        const disposeMat = (m: THREE.Material) => {
          const textured = m as THREE.MeshLambertMaterial;
          if (textured.map) textured.map.dispose();
          m.dispose();
        };
        if (Array.isArray(mat)) {
          mat.forEach(disposeMat);
        } else if (mat) {
          disposeMat(mat);
        }
      });
      this.zAssets?.dispose();
      this.renderer.dispose();
      el.remove();
    } catch (err) {
      console.error("Error while disposing the game engine", err);
    }
  }

  /* ---------------------------- Game loop ---------------------------- */

  private tick = (t: number): void => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.tick);
    const dt = Math.min(Math.max((t - this.lastT) / 1000, 0), 0.05);
    this.lastT = t;
    try {
      this.update(dt);
    } catch (err) {
      // never let one bad frame spin forever — stop and report it
      console.error("Game loop error", err);
      this.disposed = true;
      cancelAnimationFrame(this.raf);
      this.onError?.(err);
    }
  };

  private update(dt: number): void {
    const state = this.store.getSnapshot().state;
    if (state === "idle") {
      // slow cinematic pan behind the menu
      this.idleTime += dt;
      this.camera.position.set(
        Math.sin(this.idleTime * 0.3) * 2.5,
        PLAYER_HEIGHT + Math.sin(this.idleTime * 0.5) * 0.06,
        12 + Math.cos(this.idleTime * 0.23) * 2
      );
      this.camera.rotation.set(
        0.03 * Math.sin(this.idleTime * 0.4),
        Math.sin(this.idleTime * 0.16) * 0.3,
        0
      );
    } else if (state === "playing") {
      this.updatePlayer(dt);
      this.updateZombies(dt);
      this.updateWave(dt);
    }
    this.updateGun(dt);
    this.updateLights(dt);
    this.renderer.render(this.scene, this.camera);
  }

  private updatePlayer(dt: number): void {
    this.yaw -= this.lookDX * 0.0022;
    this.lookDX = 0;
    this.pitch = THREE.MathUtils.clamp(
      this.pitch - this.lookDY * 0.0022,
      -1.45,
      1.45
    );
    this.lookDY = 0;
    this.camera.rotation.set(this.pitch, this.yaw, 0);

    // movement: WASD + virtual joystick, relative to camera yaw
    let f =
      (this.keys.has("w") ? 1 : 0) -
      (this.keys.has("s") ? 1 : 0) +
      this.joystick.y;
    let r =
      (this.keys.has("d") ? 1 : 0) -
      (this.keys.has("a") ? 1 : 0) +
      this.joystick.x;
    const len = Math.hypot(f, r);
    if (len > 1) {
      f /= len;
      r /= len;
    }
    this.moving = len > 0.05;

    let vx = 0;
    let vz = 0;
    if (this.moving) {
      const fx = -Math.sin(this.yaw);
      const fz = -Math.cos(this.yaw);
      const rx = -fz;
      const rz = fx;
      vx = (fx * f + rx * r) * PLAYER_SPEED;
      vz = (fz * f + rz * r) * PLAYER_SPEED;
      this.bobTime += dt * 9;
    }

    const stepX = this.resolveCircle(
      this.pos.x + vx * dt,
      this.pos.z,
      PLAYER_RADIUS
    );
    const stepZ = this.resolveCircle(
      stepX.x,
      this.pos.z + vz * dt,
      PLAYER_RADIUS
    );
    this.pos.set(stepZ.x, 0, stepZ.z);
    this.camera.position.set(
      this.pos.x,
      PLAYER_HEIGHT + (this.moving ? Math.abs(Math.sin(this.bobTime)) * 0.05 : 0),
      this.pos.z
    );
  }

  private updateZombies(dt: number): void {
    for (const z of this.zombies) z.update(dt, this.pos, this);
    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      if (z.removable) {
        this.scene.remove(z.group);
        z.disposeMaterials();
        this.shootTargets = this.shootTargets.filter(
          (o) => (o as THREE.Mesh).userData.zombie !== z
        );
        this.zombies.splice(i, 1);
        this.syncZombieCounts();
      }
    }
  }

  private updateWave(dt: number): void {
    if (this.messageTimer > 0) {
      this.messageTimer -= dt;
      if (this.messageTimer <= 0) this.store.update({ message: "" });
    }
    if (this.toSpawn > 0) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnZombie();
        this.toSpawn -= 1;
        this.spawnTimer = 0.55;
        this.syncZombieCounts();
      }
      return;
    }
    if (this.waveEnding) {
      if (this.waveIndex >= WAVES.length - 1) return;
      this.waveBreakTimer -= dt;
      if (this.waveBreakTimer <= 0) this.startWave(this.waveIndex + 1);
      return;
    }
    const anyAlive = this.zombies.some((z) => z.alive);
    if (!anyAlive) {
      this.waveEnding = true;
      if (this.waveIndex >= WAVES.length - 1) {
        this.store.update({ state: "won", message: "" });
        this.firing = false;
        this.audio.wave();
      } else {
        this.setMessage(`WAVE ${this.waveIndex + 1} CLEARED — PREPARE`);
        this.waveBreakTimer = 3.2;
      }
    }
  }

  private updateGun(dt: number): void {
    this.fireCooldown = Math.max(0, this.fireCooldown - dt);

    if (this.reloading) {
      this.reloadTimer -= dt;
      const t = 1 - THREE.MathUtils.clamp(this.reloadTimer / RELOAD_TIME, 0, 1);
      this.gun.position.y = -0.28 - Math.sin(t * Math.PI) * 0.18;
      if (this.reloadTimer <= 0) {
        const amount = Math.min(MAG_SIZE - this.mag, this.reserve);
        this.mag += amount;
        this.reserve -= amount;
        this.reloading = false;
        this.store.update({ ammo: this.mag, reserve: this.reserve });
      }
    } else {
      this.recoil = Math.max(0, this.recoil - dt * 6);
      this.gun.position.y = -0.28 + Math.sin(this.bobTime) * 0.018;
      this.gun.position.z = -0.55 + this.recoil * 0.14;
      this.gun.rotation.x = -0.08 + this.recoil * 0.22;
    }

    if (this.flashTime > 0) {
      this.flashTime = Math.max(0, this.flashTime - dt);
      const k = this.flashTime / 0.07;
      this.muzzleFlash.material.opacity = k;
      this.muzzleLight.intensity = k * 120;
    } else if (this.muzzleFlash.material.opacity !== 0) {
      this.muzzleFlash.material.opacity = 0;
      this.muzzleLight.intensity = 0;
    }

    if (this.tracer.visible) {
      this.tracerTime -= dt;
      if (this.tracerTime <= 0) {
        this.tracer.visible = false;
      } else {
        this.tracer.material.opacity = (this.tracerTime / 0.09) * 0.9;
      }
    }

    if (this.firing && (this.isTouch || this.locked)) {
      this.tryShoot();
    }
  }

  /** Move the point-light pool onto whichever lamp posts are nearest the player. */
  private assignStreetLights(): void {
    if (this.lampSpots.length === 0) return;
    const near = [...this.lampSpots]
      .sort(
        (a, b) =>
          (a.x - this.pos.x) ** 2 +
          (a.z - this.pos.z) ** 2 -
          ((b.x - this.pos.x) ** 2 + (b.z - this.pos.z) ** 2)
      )
      .slice(0, this.streetLights.length);
    for (let i = 0; i < this.streetLights.length; i++) {
      const spot = near[i] ?? near[near.length - 1];
      this.streetLights[i].position.set(spot.x, LAMP_HEIGHT, spot.z);
    }
  }

  private updateLights(dt: number): void {
    this.flickerTime += dt;

    // re-target the lamp light pool a few times a second as the player moves
    this.lampSyncTimer -= dt;
    if (this.lampSyncTimer <= 0) {
      this.lampSyncTimer = 0.3;
      this.assignStreetLights();
    }

    for (let i = 0; i < this.streetLights.length; i++) {
      const l = this.streetLights[i];
      if (i === 0) {
        // one faulty lamp that flickers
        const flick =
          0.75 +
          0.25 *
            Math.sin(this.flickerTime * 27) *
            Math.sin(this.flickerTime * 6.1 + 1.7);
        l.intensity = LAMP_INTENSITY * flick;
      } else {
        l.intensity =
          LAMP_INTENSITY * (0.96 + 0.04 * Math.sin(this.flickerTime * 9 + i * 2.4));
      }
    }
  }

  /* ---------------------------- Shooting ---------------------------- */

  private tryShoot(): void {
    if (this.store.getSnapshot().state !== "playing") return;
    if (this.reloading || this.fireCooldown > 0) return;
    if (this.mag <= 0) {
      this.fireCooldown = 0.18;
      this.audio.click();
      this.reload();
      return;
    }
    this.mag -= 1;
    this.fireCooldown = FIRE_INTERVAL;
    this.recoil = 1;
    this.flashTime = 0.07;
    this.audio.shoot();
    this.store.update({ ammo: this.mag });

    this.camera.updateMatrixWorld();
    this.tmpMuzzle.set(0, 0.055, -0.5).applyMatrix4(this.gun.matrixWorld);
    this.camera.getWorldDirection(this.tmpDir);
    this.raycaster.setFromCamera(AIM_POINT, this.camera);
    const hits = this.raycaster.intersectObjects(this.shootTargets, false);

    let end = this.tmpMuzzle.clone().addScaledVector(this.tmpDir, 90);
    if (hits.length > 0 && hits[0].distance <= 90) {
      const hit = hits[0];
      end = hit.point.clone();
      const zombie = (hit.object as THREE.Mesh).userData.zombie as
        | Zombie
        | undefined;
      if (zombie) {
        const killed = zombie.damage(SHOT_DAMAGE);
        this.audio.hit();
        const s = this.store.getSnapshot();
        this.store.update({ hitTick: s.hitTick + 1 });
        if (killed) {
          this.kills += 1;
          this.audio.die();
          this.store.update({ kills: this.kills });
          this.shootTargets = this.shootTargets.filter(
            (o) => (o as THREE.Mesh).userData.zombie !== zombie
          );
        }
        this.syncZombieCounts();
      }
    }

    const attr = this.tracer.geometry.attributes.position as THREE.BufferAttribute;
    attr.setXYZ(0, this.tmpMuzzle.x, this.tmpMuzzle.y, this.tmpMuzzle.z);
    attr.setXYZ(1, end.x, end.y, end.z);
    attr.needsUpdate = true;
    this.tracer.geometry.computeBoundingSphere();
    this.tracer.material.opacity = 0.9;
    this.tracer.visible = true;
    this.tracerTime = 0.09;
  }

  /* ---------------------------- Waves ---------------------------- */

  private startWave(index: number): void {
    this.waveIndex = index;
    this.toSpawn = WAVES[index];
    this.spawnTimer = 0;
    this.waveEnding = false;
    this.store.update({
      wave: index + 1,
      zombiesAlive: 0,
      zombiesRemaining: this.toSpawn,
    });
    this.setMessage(
      `WAVE ${index + 1} / ${WAVES.length} — ${this.toSpawn} ZOMBIES INCOMING`
    );
    this.audio.wave();
  }

  private setMessage(msg: string): void {
    this.messageTimer = 2.6;
    this.store.update({ message: msg });
  }

  private spawnZombie(): void {
    let x = 0;
    let z = 0;
    for (let attempt = 0; attempt < 12; attempt++) {
      const ang = Math.random() * Math.PI * 2;
      const rad = 30 + Math.random() * 26;
      const res = this.resolveCircle(
        this.pos.x + Math.cos(ang) * rad,
        this.pos.z + Math.sin(ang) * rad,
        0.6
      );
      x = res.x;
      z = res.z;
      if (Math.hypot(x - this.pos.x, z - this.pos.z) >= 16) break;
    }
    const zombie = new Zombie(this.scene, x, z, this.zAssets);
    this.zombies.push(zombie);
    this.shootTargets.push(...zombie.hitMeshes);
  }

  private syncZombieCounts(): void {
    const alive = this.zombies.reduce((n, z) => n + (z.alive ? 1 : 0), 0);
    this.store.update({
      zombiesAlive: alive,
      zombiesRemaining: alive + this.toSpawn,
    });
  }

  private reset(): void {
    for (const z of this.zombies) {
      this.scene.remove(z.group);
      z.disposeMaterials();
    }
    this.zombies = [];
    this.shootTargets = [this.buildingMesh, this.groundMesh];
    this.health = 100;
    this.mag = MAG_SIZE;
    this.reserve = START_RESERVE;
    this.kills = 0;
    this.waveIndex = -1;
    this.toSpawn = 0;
    this.waveEnding = false;
    this.waveBreakTimer = 0;
    this.messageTimer = 0;
    this.fireCooldown = 0;
    this.reloading = false;
    this.reloadTimer = 0;
    this.recoil = 0;
    this.flashTime = 0;
    this.tracer.visible = false;
    this.firing = false;
    this.pos.set(0, 0, 12);
    this.yaw = 0;
    this.pitch = 0;
    this.bobTime = 0;
    this.joystick.x = 0;
    this.joystick.y = 0;
    this.camera.rotation.set(0, 0, 0);
    this.camera.position.set(0, PLAYER_HEIGHT, 12);
    this.assignStreetLights();
    this.store.update({
      health: 100,
      wave: 0,
      ammo: MAG_SIZE,
      reserve: START_RESERVE,
      zombiesAlive: 0,
      zombiesRemaining: 0,
      kills: 0,
      message: "",
    });
  }
}
