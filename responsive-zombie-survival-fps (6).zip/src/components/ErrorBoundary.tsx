import { Component } from "react";
import type { ErrorInfo, ReactNode } from "react";

interface Props {
  children: ReactNode;
}

interface State {
  message: string | null;
}

/**
 * Catches any render/lifecycle crash so the player always sees a readable
 * screen instead of a blank page.
 */
export default class ErrorBoundary extends Component<Props, State> {
  state: State = { message: null };

  static getDerivedStateFromError(error: unknown): State {
    return {
      message:
        error instanceof Error ? error.message : String(error ?? "Unknown error"),
    };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error("DISTRICT crashed:", error, info.componentStack);
  }

  render(): ReactNode {
    if (this.state.message === null) return this.props.children;
    return (
      <div className="game-root flex items-center justify-center bg-black p-6">
        <div className="max-w-md text-center">
          <div className="text-[clamp(22px,6vw,34px)] font-black tracking-[0.12em] text-red-600">
            SYSTEM FAILURE
          </div>
          <p className="mt-3 text-[clamp(11px,2.8vw,14px)] font-medium text-white/70">
            The game could not start on this device.
          </p>
          <pre className="mt-4 max-h-40 overflow-auto rounded-lg border border-white/15 bg-white/5 p-3 text-left text-[11px] whitespace-pre-wrap text-red-300">
            {this.state.message}
          </pre>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="mt-5 rounded-xl border-2 border-red-400/70 bg-red-600/90 px-8 py-3 text-[clamp(13px,3.4vw,17px)] font-black tracking-[0.25em] text-white active:scale-95"
          >
            ↻ RELOAD
          </button>
        </div>
      </div>
    );
  }
}
