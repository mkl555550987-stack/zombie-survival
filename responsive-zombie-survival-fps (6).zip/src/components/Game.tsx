import {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import type { ReactNode } from "react";
import { GameStore, ZombieEngine } from "../game/engine";

/** Safe-area aware offsets so the HUD never leaves the screen (notches etc). */
const SAFE = {
  top: "max(12px, env(safe-area-inset-top))",
  right: "max(12px, env(safe-area-inset-right))",
  bottom: "max(12px, env(safe-area-inset-bottom))",
  left: "max(12px, env(safe-area-inset-left))",
};

export default function Game() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<ZombieEngine | null>(null);
  const storeRef = useRef<GameStore | null>(null);
  if (!storeRef.current) storeRef.current = new GameStore();
  const store = storeRef.current;

  const stats = useSyncExternalStore(store.subscribe, store.getSnapshot);
  const [started, setStarted] = useState(false);
  const [engineError, setEngineError] = useState<string | null>(null);
  const isTouch = useMemo(
    () => "ontouchstart" in window || navigator.maxTouchPoints > 0,
    []
  );

  useEffect(() => {
    const mount = containerRef.current;
    if (!mount) return;
    let engine: ZombieEngine | null = null;
    const report = (err: unknown) => {
      console.error("Failed to run 3D engine", err);
      setEngineError(
        err instanceof Error ? err.message : String(err ?? "Unknown error")
      );
    };
    try {
      engine = new ZombieEngine(mount, store, report);
      engineRef.current = engine;
    } catch (err) {
      report(err);
    }
    return () => {
      try {
        engine?.dispose();
      } catch (err) {
        console.error("Error disposing engine", err);
      }
      engineRef.current = null;
    };
  }, [store]);

  const handleStart = () => {
    engineRef.current?.start();
    setStarted(true);
  };

  const healthColor =
    stats.health > 60 ? "#22c55e" : stats.health > 30 ? "#f59e0b" : "#ef4444";

  return (
    <div className="game-root">
      {/* 3D canvas mount (engine appends a 100% x 100% canvas here) */}
      <div ref={containerRef} className="absolute inset-0 overflow-hidden" />

      {/* vignette */}
      <div
        className="pointer-events-none absolute inset-0 z-[5]"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 58%, rgba(0,0,0,0.40) 100%)",
        }}
      />

      {/* ============================ HUD ============================ */}
      <div className="pointer-events-none absolute inset-0 z-10">
        {/* top bar: health / wave / kills */}
        <div
          className="absolute left-0 right-0 top-0 flex items-start justify-between gap-2"
          style={{ padding: `${SAFE.top} ${SAFE.right} 0px ${SAFE.left}` }}
        >
          {/* health */}
          <div className="flex flex-col gap-1">
            <div className="flex items-baseline gap-2">
              <span className="text-[clamp(10px,2.4vw,13px)] font-bold tracking-[0.22em] text-white/85">
                HEALTH
              </span>
              <span className="text-[clamp(11px,2.6vw,14px)] font-black tabular-nums text-white">
                {stats.health}%
              </span>
            </div>
            <div
              className={`h-[clamp(8px,1.8vw,12px)] w-[clamp(120px,26vw,240px)] overflow-hidden rounded-full border bg-black/55 ${
                stats.health <= 30
                  ? "animate-pulse border-red-500/80"
                  : "border-white/25"
              }`}
            >
              <div
                className="h-full rounded-full transition-[width] duration-200"
                style={{ width: `${stats.health}%`, backgroundColor: healthColor }}
              />
            </div>
          </div>

          {/* wave */}
          <div className="flex flex-col items-center gap-0.5 text-center">
            <div
              className="text-[clamp(14px,3.2vw,20px)] font-black tracking-[0.18em] text-white"
              style={{ textShadow: "0 2px 10px rgba(0,0,0,0.95)" }}
            >
              WAVE {Math.max(1, stats.wave)}
              <span className="text-white/55"> / {stats.totalWaves}</span>
            </div>
            <div className="text-[clamp(9px,2.2vw,12px)] font-semibold tracking-[0.18em] text-amber-200/85">
              ZOMBIES: {stats.zombiesRemaining}
            </div>
          </div>

          {/* kills */}
          <div className="text-right">
            <div className="text-[clamp(10px,2.4vw,13px)] font-bold tracking-[0.22em] text-white/85">
              KILLS
            </div>
            <div
              className="text-[clamp(14px,3.4vw,20px)] font-black tabular-nums text-white"
              style={{ textShadow: "0 2px 10px rgba(0,0,0,0.95)" }}
            >
              {stats.kills}
            </div>
          </div>
        </div>

        {/* wave message */}
        {stats.message !== "" && (
          <div
            className="absolute left-1/2 top-[17%] -translate-x-1/2 animate-[fadein_0.3s_ease-out] whitespace-nowrap text-center text-[clamp(12px,3.2vw,20px)] font-black tracking-[0.22em] text-amber-300"
            style={{ textShadow: "0 2px 10px rgba(0,0,0,1)" }}
          >
            {stats.message}
          </div>
        )}

        {/* crosshair */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative h-[clamp(20px,4.5vw,28px)] w-[clamp(20px,4.5vw,28px)]">
            <span className="absolute left-1/2 top-0 h-[32%] w-[2px] -translate-x-1/2 bg-white/90 shadow-[0_0_6px_rgba(255,255,255,0.9)]" />
            <span className="absolute bottom-0 left-1/2 h-[32%] w-[2px] -translate-x-1/2 bg-white/90 shadow-[0_0_6px_rgba(255,255,255,0.9)]" />
            <span className="absolute left-0 top-1/2 h-[2px] w-[32%] -translate-y-1/2 bg-white/90 shadow-[0_0_6px_rgba(255,255,255,0.9)]" />
            <span className="absolute right-0 top-1/2 h-[2px] w-[32%] -translate-y-1/2 bg-white/90 shadow-[0_0_6px_rgba(255,255,255,0.9)]" />
            <span className="absolute left-1/2 top-1/2 h-[3px] w-[3px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-white" />
          </div>
        </div>

        {/* hit marker */}
        {stats.hitTick > 0 && (
          <div
            key={stats.hitTick}
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 animate-[hitpop_0.28s_ease-out] text-[clamp(18px,5vw,28px)] font-black text-red-500"
            style={{ textShadow: "0 0 10px rgba(239,68,68,0.9)" }}
          >
            ✕
          </div>
        )}

        {/* mobile joystick (bottom-left) */}
        {isTouch && (
          <div className="absolute" style={{ left: SAFE.left, bottom: SAFE.bottom }}>
            <VirtualJoystick getEngine={() => engineRef.current} />
          </div>
        )}

        {/* bottom-right: ammo counter + mobile fire/reload */}
        <div
          className="absolute flex flex-col items-end gap-2"
          style={{ right: SAFE.right, bottom: SAFE.bottom }}
        >
          <div className="leading-none">
            <span
              className={`text-[clamp(30px,8vw,46px)] font-black tabular-nums ${
                stats.ammo === 0 ? "animate-pulse text-red-500" : "text-white"
              }`}
              style={{ textShadow: "0 2px 10px rgba(0,0,0,0.95)" }}
            >
              {stats.ammo}
            </span>
            <span className="text-[clamp(13px,3.4vw,18px)] font-bold tabular-nums text-white/75">
              {" "}
              / {stats.reserve}
            </span>
          </div>
          {!isTouch && (
            <div className="text-[10px] font-semibold tracking-[0.2em] text-white/55">
              PRESS R TO RELOAD
            </div>
          )}
          {isTouch && (
            <div className="flex items-end gap-2">
              <button
                type="button"
                aria-label="Reload"
                className="touch-none select-none rounded-xl border-2 border-white/30 bg-slate-800/70 px-4 py-3 text-[clamp(14px,3.5vw,18px)] font-black text-white shadow-lg active:bg-slate-600"
                onPointerDown={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  engineRef.current?.reload();
                }}
              >
                ⟳
              </button>
              <button
                type="button"
                aria-label="Fire"
                className="touch-none flex h-[clamp(58px,15vw,74px)] w-[clamp(58px,15vw,74px)] select-none items-center justify-center rounded-full border-2 border-red-300/60 bg-red-600/80 text-[clamp(13px,3.2vw,17px)] font-black tracking-widest text-white shadow-[0_0_24px_rgba(220,38,38,0.55)] active:scale-95"
                onPointerDown={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  e.currentTarget.setPointerCapture(e.pointerId);
                  engineRef.current?.setFiring(true);
                }}
                onPointerUp={(e) => {
                  e.stopPropagation();
                  engineRef.current?.setFiring(false);
                }}
                onPointerCancel={(e) => {
                  e.stopPropagation();
                  engineRef.current?.setFiring(false);
                }}
                onLostPointerCapture={() => engineRef.current?.setFiring(false)}
              >
                FIRE
              </button>
            </div>
          )}
        </div>

        {/* desktop controls hint */}
        {!isTouch && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 whitespace-nowrap text-[11px] font-semibold tracking-[0.18em] text-white/50">
            WASD — MOVE · MOUSE — AIM · CLICK — SHOOT · R — RELOAD
          </div>
        )}
      </div>

      {/* red damage flash */}
      {stats.hurtTick > 0 && stats.state === "playing" && (
        <div
          key={stats.hurtTick}
          className="pointer-events-none absolute inset-0 z-[15] animate-[damageflash_0.45s_ease-out]"
          style={{
            background:
              "radial-gradient(ellipse at center, rgba(190,20,20,0) 30%, rgba(150,0,0,0.55) 100%)",
          }}
        />
      )}

      {/* resume hint (desktop, pointer unlocked) */}
      {started && stats.state === "playing" && !isTouch && !stats.locked && (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
          <div className="animate-[pulsehint_1.5s_ease-in-out_infinite] rounded-xl border border-white/25 bg-black/65 px-6 py-3 text-[clamp(13px,3vw,18px)] font-black tracking-[0.28em] text-white">
            CLICK TO RESUME
          </div>
        </div>
      )}

      {/* ============================ Overlays ============================ */}

      {/* start screen */}
      {!started && !engineError && (
        <Overlay>
          <div className="flex flex-col items-center gap-4 text-center">
            <div
              className="animate-[titleflicker_4s_infinite] text-[clamp(34px,9vw,64px)] font-black tracking-[0.12em] text-red-600"
              style={{
                textShadow:
                  "0 0 24px rgba(220,38,38,0.75), 0 3px 0 rgba(0,0,0,0.8)",
              }}
            >
              DISTRICT
            </div>
            <div className="text-[clamp(13px,3.4vw,20px)] font-black tracking-[0.5em] text-white">
              ZOMBIE SURVIVAL
            </div>
            <div className="text-[clamp(10px,2.6vw,13px)] font-semibold tracking-[0.2em] text-white/55">
              NORTH QUARTER DISTRICT — NIGHT WATCH
            </div>
            <div className="my-1 h-px w-48 bg-gradient-to-r from-transparent via-red-500/60 to-transparent" />
            <div className="text-[clamp(11px,2.8vw,14px)] font-medium leading-relaxed text-white/75">
              The city is overrun. Survive{" "}
              <span className="font-black text-white">3 waves</span> of the
              undead.
              <br />
              Every bullet counts. Don&apos;t let them touch you.
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-left text-[clamp(10px,2.5vw,12px)] font-semibold tracking-[0.12em] text-white/65">
              <span>WASD — MOVE</span>
              <span>MOUSE — AIM</span>
              <span>CLICK — SHOOT</span>
              <span>R — RELOAD</span>
              {isTouch && <span>JOYSTICK — MOVE</span>}
              {isTouch && <span>DRAG — LOOK · FIRE — SHOOT</span>}
            </div>
            <button
              type="button"
              onClick={handleStart}
              className="mt-2 touch-none select-none rounded-xl border-2 border-red-400/70 bg-red-600/90 px-10 py-3 text-[clamp(15px,4vw,20px)] font-black tracking-[0.3em] text-white shadow-[0_0_30px_rgba(220,38,38,0.55)] transition-transform active:scale-95"
            >
              ▶ SURVIVE
            </button>
          </div>
        </Overlay>
      )}

      {/* engine error */}
      {engineError && (
        <Overlay>
          <div className="max-w-md text-center">
            <div className="text-[clamp(20px,5.5vw,30px)] font-black tracking-[0.12em] text-red-600">
              SYSTEM FAILURE
            </div>
            <p className="mt-3 text-[clamp(11px,2.8vw,14px)] font-medium text-white/70">
              The 3D engine could not run on this device.
            </p>
            <pre className="mt-4 max-h-40 overflow-auto rounded-lg border border-white/15 bg-white/5 p-3 text-left text-[11px] whitespace-pre-wrap text-red-300">
              {engineError}
            </pre>
          </div>
        </Overlay>
      )}

      {/* win screen */}
      {started && stats.state === "won" && (
        <Overlay>
          <div className="flex flex-col items-center gap-4 text-center">
            <div
              className="text-[clamp(30px,8vw,56px)] font-black tracking-[0.12em] text-green-500"
              style={{ textShadow: "0 0 24px rgba(34,197,94,0.7)" }}
            >
              YOU SURVIVED
            </div>
            <div className="text-[clamp(11px,2.8vw,14px)] font-semibold tracking-[0.2em] text-white/70">
              ALL {stats.totalWaves} WAVES CLEARED — {stats.kills} KILLS
            </div>
            <button
              type="button"
              onClick={handleStart}
              className="mt-2 touch-none select-none rounded-xl border-2 border-green-400/70 bg-green-600/90 px-10 py-3 text-[clamp(15px,4vw,20px)] font-black tracking-[0.3em] text-white shadow-[0_0_30px_rgba(34,197,94,0.5)] transition-transform active:scale-95"
            >
              ▶ PLAY AGAIN
            </button>
          </div>
        </Overlay>
      )}

      {/* lose screen */}
      {started && stats.state === "lost" && (
        <Overlay>
          <div className="flex flex-col items-center gap-4 text-center">
            <div
              className="text-[clamp(30px,8vw,56px)] font-black tracking-[0.12em] text-red-600"
              style={{ textShadow: "0 0 24px rgba(220,38,38,0.75)" }}
            >
              YOU DIED
            </div>
            <div className="text-[clamp(11px,2.8vw,14px)] font-semibold tracking-[0.2em] text-white/70">
              REACHED WAVE {Math.max(1, stats.wave)} — {stats.kills} KILLS
            </div>
            <button
              type="button"
              onClick={handleStart}
              className="mt-2 touch-none select-none rounded-xl border-2 border-red-400/70 bg-red-600/90 px-10 py-3 text-[clamp(15px,4vw,20px)] font-black tracking-[0.3em] text-white shadow-[0_0_30px_rgba(220,38,38,0.55)] transition-transform active:scale-95"
            >
              ▶ TRY AGAIN
            </button>
          </div>
        </Overlay>
      )}
    </div>
  );
}

/* ============================ Components ============================ */

function Overlay({ children }: { children: ReactNode }) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/82 p-6 backdrop-blur-sm">
      {children}
    </div>
  );
}

/** Virtual joystick for mobile movement (bottom-left). */
function VirtualJoystick({
  getEngine,
}: {
  getEngine: () => ZombieEngine | null;
}) {
  const baseRef = useRef<HTMLDivElement | null>(null);
  const knobRef = useRef<HTMLDivElement | null>(null);
  const pointerId = useRef<number | null>(null);

  const move = (clientX: number, clientY: number) => {
    const base = baseRef.current;
    const knob = knobRef.current;
    if (!base || !knob) return;
    const rect = base.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.36;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    knob.style.transform = `translate(${dx}px, ${dy}px)`;
    // x: right, y: up (screen dy is inverted)
    getEngine()?.setJoystick(dx / maxR, -dy / maxR);
  };

  const reset = () => {
    if (knobRef.current) knobRef.current.style.transform = "translate(0px, 0px)";
    getEngine()?.setJoystick(0, 0);
  };

  return (
    <div
      ref={baseRef}
      aria-label="Movement joystick"
      className="relative h-[clamp(96px,24vw,132px)] w-[clamp(96px,24vw,132px)] touch-none select-none rounded-full border-2 border-white/25 bg-white/5 shadow-[0_0_20px_rgba(0,0,0,0.6)] backdrop-blur-sm"
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        pointerId.current = e.pointerId;
        baseRef.current?.setPointerCapture(e.pointerId);
        move(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (pointerId.current === e.pointerId) {
          e.preventDefault();
          move(e.clientX, e.clientY);
        }
      }}
      onPointerUp={(e) => {
        if (pointerId.current === e.pointerId) {
          pointerId.current = null;
          reset();
        }
      }}
      onPointerCancel={(e) => {
        if (pointerId.current === e.pointerId) {
          pointerId.current = null;
          reset();
        }
      }}
    >
      <div
        ref={knobRef}
        className="absolute left-[29%] top-[29%] h-[42%] w-[42%] rounded-full border border-white/40 bg-white/20 shadow-inner"
      />
    </div>
  );
}
